--ＣＣ隻眼のパスト・アイ
function c3465.initial_effect(c)
end
